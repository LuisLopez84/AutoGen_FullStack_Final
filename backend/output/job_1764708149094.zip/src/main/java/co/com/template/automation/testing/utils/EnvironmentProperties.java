package co.com.template.automation.testing.utils;

import net.serenitybdd.model.environment.EnvironmentSpecificConfiguration;
import net.thucydides.model.environment.SystemEnvironmentVariables;

public final class EnvironmentProperties {

    private EnvironmentProperties() {
        // Utility class
    }

    public static String getProperty(String propertyName) {
        return EnvironmentSpecificConfiguration.from(
            SystemEnvironmentVariables.createEnvironmentVariables()
        ).getProperty(propertyName);
    }

    public static String getUrl() {
        return getProperty("webdriver.base.url");
    }
}