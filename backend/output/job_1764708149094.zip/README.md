# Serenity BDD Automation Project

Proyecto generado automáticamente para automatización de pruebas.