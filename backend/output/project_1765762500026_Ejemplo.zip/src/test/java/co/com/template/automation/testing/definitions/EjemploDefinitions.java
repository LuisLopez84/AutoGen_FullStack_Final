package co.com.template.automation.testing.definitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.actors.OnStage;
import co.com.template.automation.testing.tasks.EjemploTask;
import co.com.template.automation.testing.questions.EjemploQuestion;

public class EjemploDefinitions {

    @Given("el usuario está en la página principal de Mercado Libre")
    public void elUsuarioEstaEnLaPaginaPrincipal() {
        OnStage.theActorInTheSpotlight().attemptsTo(EjemploTask.abrirPaginaPrincipal());
    }

    @When("el usuario busca {string}")
    public void elUsuarioBusca(String busqueda) {
        OnStage.theActorInTheSpotlight().attemptsTo(EjemploTask.realizarBusqueda(busqueda));
    }

    @Then("se muestran los resultados de búsqueda de portátiles")
    public void seMuestranLosResultadosDeBusqueda() {
        OnStage.theActorInTheSpotlight().should(Ensure.that(EjemploQuestion.resultadosDeBusqueda()).isNotEmpty());
    }

    @When("el usuario selecciona un producto de la lista")
    public void elUsuarioSeleccionaUnProducto() {
        OnStage.theActorInTheSpotlight().attemptsTo(EjemploTask.seleccionarProducto());
    }

    @Then("se muestra la página del producto seleccionado")
    public void seMuestraLaPaginaDelProductoSeleccionado() {
        OnStage.theActorInTheSpotlight().should(Ensure.that(EjemploQuestion.paginaDelProducto()).isDisplayed());
    }

    @Then("se muestra un mensaje de error indicando que la búsqueda no puede estar vacía")
    public void seMuestraMensajeDeError() {
        OnStage.theActorInTheSpotlight().should(Ensure.that(EjemploQuestion.mensajeDeError()).isDisplayed());
    }
}