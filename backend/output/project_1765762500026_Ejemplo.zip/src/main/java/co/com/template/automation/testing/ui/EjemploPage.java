package co.com.template.automation.testing.ui;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;

public class EjemploPage extends PageObject {
    public static final Target BUSCADOR = Target.the("buscador").locatedBy("#cb1-edit");
    public static final Target RESULTADOS = Target.the("resultados de búsqueda").locatedBy("div.results");
    public static final Target PRODUCTO_SELECCIONADO = Target.the("producto seleccionado").locatedBy("a.poly-component__title");
    public static final Target MENSAJE_ERROR = Target.the("mensaje de error").locatedBy(".error-message");
}