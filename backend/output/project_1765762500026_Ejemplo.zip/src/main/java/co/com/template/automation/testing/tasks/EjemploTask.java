package co.com.template.automation.testing.tasks;

import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.Click;
import co.com.template.automation.testing.ui.EjemploPage;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class EjemploTask {

    public static Task abrirPaginaPrincipal() {
        return instrumented(Open.class, EjemploPage.class);
    }

    public static Task realizarBusqueda(String busqueda) {
        return instrumented(EjemploTask.class, busqueda);
    }

    public static Task seleccionarProducto() {
        return instrumented(Click.on(EjemploPage.PRODUCTO_SELECCIONADO));
    }
}