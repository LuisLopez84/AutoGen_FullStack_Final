package co.com.template.automation.testing.questions;

import net.serenitybdd.screenplay.Question;
import co.com.template.automation.testing.ui.EjemploPage;

public class EjemploQuestion {

    public static Question<Boolean> resultadosDeBusqueda() {
        return actor -> EjemploPage.RESULTADOS.resolveFor(actor).isDisplayed();
    }

    public static Question<Boolean> paginaDelProducto() {
        return actor -> EjemploPage.PRODUCTO_SELECCIONADO.resolveFor(actor).isDisplayed();
    }

    public static Question<Boolean> mensajeDeError() {
        return actor -> EjemploPage.MENSAJE_ERROR.resolveFor(actor).isDisplayed();
    }
}