package runners;

import io.cucumber.junit.platform.engine.Cucumber;

@Cucumber
public class CucumberTestSuiteTest {}