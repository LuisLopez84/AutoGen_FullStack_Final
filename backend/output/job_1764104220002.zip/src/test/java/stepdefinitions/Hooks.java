package stepdefinitions;

import io.cucumber.java.Before;
import io.cucumber.java.After;

public class Hooks {
    @Before
    public void setUp() {
        // Setup code here
    }

    @After
    public void tearDown() {
        // Teardown code here
    }
}