package commons;

public class StepUrl {
    public static final String BASE_URL = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
}