# Serenity BDD Automation Project

Proyecto generado automáticamente para automatización de pruebas.

## Estructura
- src/main/java: Clases Screenplay (Tasks, Questions, Pages)
- src/test/java: Runners y Step Definitions
- src/test/resources: Configuraciones y Features